package com.azamseataxi.seaman;
import android.content.*;import android.net.Uri;import androidx.core.content.FileProvider;import com.getcapacitor.*;import com.getcapacitor.annotation.*;import java.io.File;
@CapacitorPlugin(name="SeataxiFiles") public class SeataxiFilesPlugin extends Plugin{
 @PluginMethod public void openFile(PluginCall c){String path=c.getString("path","");String mime=c.getString("mimeType","application/octet-stream");if(path.isEmpty()){c.reject("Missing file path");return;}try{Uri u=Uri.parse(path);if("file".equalsIgnoreCase(u.getScheme()))u=FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",new File(u.getPath()));Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(u,mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);getContext().startActivity(i);c.resolve();}catch(Exception e){c.reject("No application can open this file",e);}}
}
