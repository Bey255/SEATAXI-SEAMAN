package com.azamseataxi.seaman;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.*;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* Part 1: the authoritative trip-detection engine now lives here, native,
   independent of the WebView/JS being alive. FusedLocationProviderClient
   (~750ms/500ms fastest) replaces the old LocationManager/8000ms path.
   Every sample is validated against the monotonic elapsedRealtimeNanos
   clock, never wall-clock alone, so a stale/duplicate/out-of-order fix can
   never overwrite a newer one or re-trigger a transition. A confirmed trip
   is written to TripDb (SQLite) durably and exactly once, guarded both by
   the persisted geofence state machine (trip_state) and the trip row's
   own deterministic id. JavaScript becomes a CONSUMER of this persisted
   state (via SeataxiLocationPlugin.getPersistedTrips), not the authority —
   there is exactly one trip engine, native, so the JS-side checkGeofence
   is no longer invoked when running on this native platform (see
   GPSService in www/index.html). onStartCommand returns
   START_REDELIVER_INTENT on the real tracking path so Android can recreate
   this service and have it resume from persisted state, not from zero. */
public class LocationForegroundService extends Service {
  public static final String CHANNEL_ID="seataxi_operation_channel";
  public static final int NOTIFICATION_ID=4201;
  public static final String ACTION_START="com.azamseataxi.seaman.action.START";
  public static final String ACTION_STOP="com.azamseataxi.seaman.action.STOP";
  public static final String ACTION_LOCATION_UPDATE="com.azamseataxi.seaman.LOCATION_UPDATE";
  public static final String ACTION_TRIP_PERSISTED="com.azamseataxi.seaman.TRIP_PERSISTED";
  public static final String EXTRA_LAT="lat", EXTRA_LNG="lng", EXTRA_ACCURACY="accuracy", EXTRA_SPEED="speed", EXTRA_BEARING="bearing", EXTRA_TIME="time", EXTRA_ELAPSED_REALTIME="elapsedRealtime", EXTRA_CUTOFF="cutoffTimestamp", EXTRA_LANGUAGE="language";
  public static final String EXTRA_OPERATION_ID="operationId", EXTRA_DAR_LAT="darLat", EXTRA_DAR_LNG="darLng", EXTRA_KIG_LAT="kigLat", EXTRA_KIG_LNG="kigLng";
  public static final String EXTRA_TRIP_ID="tripId", EXTRA_TRIP_TERMINAL="tripTerminal", EXTRA_TRIP_TIME="tripTime";
  private static final long INTERVAL_MS=750L; private static final long FASTEST_INTERVAL_MS=500L; private static final int ALARM_BASE=51000;
  private static final double GEOFENCE_RADIUS_M=150; private static final double GEOFENCE_REARM_RADIUS_M=210; // radius + 60, mirrors the JS hysteresis band
  private static final long TRIP_COOLDOWN_MS=3*60*1000;
  private FusedLocationProviderClient fused; private boolean tracking=false; private long cutoff=0; private long lastScheduledCutoff=0; private String language="sw"; private final Handler h=new Handler(Looper.getMainLooper()); private Runnable cutoffTask;
  private long lastElapsedRealtimeNanos=Long.MIN_VALUE; // monotonic guard against stale/duplicate/out-of-order fixes
  private String operationId; private double darLat,darLng,kigLat,kigLng; private boolean hasStations=false;
  private TripDb.TripState tripState;
  private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor(); // DB work off the location callback thread

  private double haversineM(double lat1,double lon1,double lat2,double lon2){
    double R=6371000; double dLat=Math.toRadians(lat2-lat1); double dLon=Math.toRadians(lon2-lon1);
    double a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
    return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
  }

  /* Part 1.5/1.8: mirrors the JS checkGeofence state machine exactly (same
   * radius, same cooldown, same "first arrival only establishes position,
   * only an alternating arrival is a trip" rule), but persisted so it
   * survives service/process recreation (Part 1.4). Runs synchronously on
   * the callback thread (cheap: two haversine calls + a few comparisons);
   * only the SQLite writes are pushed to dbExecutor. */
  private void processLocationForTrips(double lat,double lng,long fixTimeMillis){
    if(!hasStations || operationId==null) return;
    if(tripState==null) tripState = TripDb.get(this).loadState(operationId);
    boolean mutated=false;
    double distDar=haversineM(lat,lng,darLat,darLng);
    double distKig=haversineM(lat,lng,kigLat,kigLng);
    mutated |= evaluateZone("Dar", distDar, fixTimeMillis);
    mutated |= evaluateZone("Kigamboni", distKig, fixTimeMillis);
    if(mutated){
      final TripDb.TripState snapshot = copyState(tripState);
      dbExecutor.execute(()-> TripDb.get(this).saveState(operationId, snapshot));
    }
  }
  private TripDb.TripState copyState(TripDb.TripState s){
    TripDb.TripState c=new TripDb.TripState(); c.lastZone=s.lastZone; c.canCountDar=s.canCountDar; c.canCountKig=s.canCountKig;
    c.lastZoneTsDar=s.lastZoneTsDar; c.lastZoneTsKig=s.lastZoneTsKig; c.lastElapsedRealtime=s.lastElapsedRealtime; c.loadStartMs=s.loadStartMs; return c;
  }
  private boolean evaluateZone(String zoneLabel, double dist, long fixTimeMillis){
    boolean isDar = zoneLabel.equals("Dar");
    boolean canCount = isDar ? tripState.canCountDar : tripState.canCountKig;
    long lastTs = isDar ? tripState.lastZoneTsDar : tripState.lastZoneTsKig;
    boolean mutated=false;
    if(dist <= GEOFENCE_RADIUS_M){
      long now=System.currentTimeMillis();
      if(canCount && (lastTs==0 || (now-lastTs)>TRIP_COOLDOWN_MS)){
        if(tripState.loadStartMs==0){ tripState.loadStartMs=fixTimeMillis; mutated=true; } // Load Start, rule 31/W
        if(tripState.lastZone==null){
          tripState.lastZone=zoneLabel; mutated=true; // first fix only establishes position — never a trip
        } else if(!tripState.lastZone.equals(zoneLabel)){
          tripState.lastZone=zoneLabel; mutated=true;
          persistTrip(zoneLabel, fixTimeMillis); // genuine DAR<->KIGAMBONI crossing
        }
        if(isDar){ tripState.canCountDar=false; tripState.lastZoneTsDar=now; } else { tripState.canCountKig=false; tripState.lastZoneTsKig=now; }
        mutated=true;
      }
    } else if(dist > GEOFENCE_REARM_RADIUS_M){
      if(isDar && !tripState.canCountDar){ tripState.canCountDar=true; mutated=true; }
      if(!isDar && !tripState.canCountKig){ tripState.canCountKig=true; mutated=true; }
    }
    return mutated;
  }
  private void persistTrip(String terminal, long fixTimeMillis){
    // Deterministic id: a retried/duplicate delivery of the SAME confirming
    // fix produces the SAME id and is safely ignored by SQLite (Part 1.5/1.8).
    final String id = operationId+"|"+terminal+"|"+fixTimeMillis;
    final String opId = operationId;
    dbExecutor.execute(()->{
      boolean inserted = TripDb.get(this).insertTripIfNew(id, opId, terminal, "auto", fixTimeMillis);
      if(inserted){
        Intent i=new Intent(ACTION_TRIP_PERSISTED).setPackage(getPackageName());
        i.putExtra(EXTRA_TRIP_ID,id); i.putExtra(EXTRA_TRIP_TERMINAL,terminal); i.putExtra(EXTRA_TRIP_TIME,fixTimeMillis); i.putExtra(EXTRA_OPERATION_ID,opId);
        sendBroadcast(i); // best-effort nudge to JS if it's alive; durability does not depend on this
      }
    });
  }

  private final LocationCallback callback=new LocationCallback(){
    @Override public void onLocationResult(LocationResult result){
      if(result==null) return;
      android.location.Location l=result.getLastLocation();
      if(l==null) return;
      if(cutoff>0 && System.currentTimeMillis()>=cutoff){ stopTrackingAndSelf(); return; }
      long elapsedNanos = l.getElapsedRealtimeNanos();
      if(elapsedNanos<=lastElapsedRealtimeNanos) return; // stale/duplicate/out-of-order — discard (rule AP)
      lastElapsedRealtimeNanos = elapsedNanos;
      processLocationForTrips(l.getLatitude(), l.getLongitude(), l.getTime());
      Intent i=new Intent(ACTION_LOCATION_UPDATE).setPackage(getPackageName());
      i.putExtra(EXTRA_LAT,l.getLatitude());
      i.putExtra(EXTRA_LNG,l.getLongitude());
      i.putExtra(EXTRA_ACCURACY,l.getAccuracy());
      i.putExtra(EXTRA_SPEED,l.hasSpeed()?l.getSpeed():-1f);
      i.putExtra(EXTRA_BEARING,l.hasBearing()?l.getBearing():-1f);
      i.putExtra(EXTRA_TIME,l.getTime());
      i.putExtra(EXTRA_ELAPSED_REALTIME, elapsedNanos/1000000L);
      sendBroadcast(i);
    }
  };
  @Override public void onCreate(){ super.onCreate(); fused=LocationServices.getFusedLocationProviderClient(this); createChannel(); }
  @Override public int onStartCommand(Intent in,int flags,int id){
    String a=in==null?ACTION_START:in.getAction(); if(ACTION_STOP.equals(a)){stopTrackingAndSelf();return START_NOT_STICKY;}
    if(in!=null){
      cutoff=in.getLongExtra(EXTRA_CUTOFF,cutoff); String x=in.getStringExtra(EXTRA_LANGUAGE); if(x!=null)language=x;
      String opId=in.getStringExtra(EXTRA_OPERATION_ID);
      if(opId!=null){
        operationId=opId;
        darLat=in.getDoubleExtra(EXTRA_DAR_LAT,0); darLng=in.getDoubleExtra(EXTRA_DAR_LNG,0);
        kigLat=in.getDoubleExtra(EXTRA_KIG_LAT,0); kigLng=in.getDoubleExtra(EXTRA_KIG_LNG,0);
        hasStations = (darLat!=0||darLng!=0) && (kigLat!=0||kigLng!=0);
        tripState=null; // reload for this operation on first location (Part 1.4 recovery)
      }
    }
    if(cutoff<=System.currentTimeMillis()){stopTrackingAndSelf();return START_NOT_STICKY;}
    startTracking();
    return START_REDELIVER_INTENT;
  }
  private void startTracking(){
    if(tracking)return; boolean fine=ContextCompat.checkSelfPermission(this,"android.permission.ACCESS_FINE_LOCATION")==PackageManager.PERMISSION_GRANTED; boolean coarse=ContextCompat.checkSelfPermission(this,"android.permission.ACCESS_COARSE_LOCATION")==PackageManager.PERMISSION_GRANTED; if(!fine&&!coarse){stopSelf();return;}
    Intent tapIntent=getPackageManager().getLaunchIntentForPackage(getPackageName());
    if(tapIntent!=null) tapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent tapPending=tapIntent==null?null:PendingIntent.getActivity(this,4202,tapIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new NotificationCompat.Builder(this,CHANNEL_ID).setContentTitle("SEATAXI SEAMAN").setContentText(language.equals("en")?"Operation in progress":"Operation inaendelea").setSmallIcon(R.drawable.ic_stat_seataxi).setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).setContentIntent(tapPending).build();
    try{
      if(Build.VERSION.SDK_INT>=29) ServiceCompat.startForeground(this,NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION); else startForeground(NOTIFICATION_ID,n);
      LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, INTERVAL_MS)
        .setMinUpdateIntervalMillis(FASTEST_INTERVAL_MS)
        .setWaitForAccurateLocation(false)
        .build();
      lastElapsedRealtimeNanos=Long.MIN_VALUE;
      fused.requestLocationUpdates(req, callback, Looper.getMainLooper());
      tracking=true; scheduleTimes();
    }catch(Exception e){stopTrackingAndSelf();}
  }
  private void scheduleTimes(){
    cancelTimes(); if(cutoff<=0)return; lastScheduledCutoff=cutoff; long[] t={cutoff-1800000L,cutoff-900000L,cutoff-300000L,cutoff-60000L,cutoff}; for(int i=0;i<t.length;i++)if(t[i]>System.currentTimeMillis())scheduleAlarm(t[i],i);
    cutoffTask=()->{if(System.currentTimeMillis()>=cutoff)stopTrackingAndSelf();else scheduleTimes();}; h.postDelayed(cutoffTask,Math.max(1000L,cutoff-System.currentTimeMillis()));
  }
  private void scheduleAlarm(long when,int index){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(am==null)return; Intent i=new Intent(this,OperationAlarmReceiver.class).setPackage(getPackageName()); i.putExtra(OperationAlarmReceiver.EXTRA_INDEX,index); i.putExtra(EXTRA_CUTOFF,cutoff); i.putExtra(EXTRA_LANGUAGE,language); PendingIntent p=PendingIntent.getBroadcast(this,ALARM_BASE+index,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); try{ if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p); else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p); else am.setExact(AlarmManager.RTC_WAKEUP,when,p);}catch(SecurityException e){if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);}
  }
  private void cancelTimes(){lastScheduledCutoff=0;if(cutoffTask!=null)h.removeCallbacks(cutoffTask);cutoffTask=null;AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);if(am==null)return;for(int i=0;i<5;i++){Intent x=new Intent(this,OperationAlarmReceiver.class).setPackage(getPackageName());PendingIntent p=PendingIntent.getBroadcast(this,ALARM_BASE+i,x,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(p);p.cancel();}}
  private void stopTrackingAndSelf(){cancelTimes();if(fused!=null&&tracking)try{fused.removeLocationUpdates(callback);}catch(Exception ignored){}tracking=false;ServiceCompat.stopForeground(this,ServiceCompat.STOP_FOREGROUND_REMOVE);stopSelf();}
  private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL_ID,"SEATAXI SEAMAN — Operation",NotificationManager.IMPORTANCE_LOW);c.setShowBadge(false);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
  @Override public void onDestroy(){if(fused!=null&&tracking)try{fused.removeLocationUpdates(callback);}catch(Exception ignored){}cancelTimes();tracking=false;super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
