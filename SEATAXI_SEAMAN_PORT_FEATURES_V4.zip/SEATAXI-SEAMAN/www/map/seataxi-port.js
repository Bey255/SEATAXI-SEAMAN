/* SEATAXI port features layer (Dar es Salaam port channel) — local data only, works offline.
   Data:   window.SEATAXI_PORT_FEATURES  (map/port-features.js, generated from the KML by scripts/kml-to-geojson.mjs)
   Icons:  map/icons/buoy-port.png (red) · map/icons/buoy-starboard.png (green)  — the pictures supplied by the owner.
   Used by map/seataxi-map.js:
     SeataxiPort.styleParts(P)          -> {sources, layers} merged into the MapLibre style (sewer line + buoy symbols)
     SeataxiPort.patchMarine(geojson)   -> port-channel route redrawn THROUGH the middle of each starboard/port buoy pair
     SeataxiPort.createLabelManager()   -> collision-free labels (priority + zoom based, no overlapping text)
     SeataxiPort.attach(map, ctx)       -> number labels for buoys, names-only landmarks, tap info, legend, "View Port Features" */
(function(){
  'use strict';

  var COLORS = { port:'#ED1B24', starboard:'#0CB04D', sewer:'#000000' };       // sampled from the supplied buoy pictures
  var ICON_FILES = { port:'map/icons/buoy-port.png', starboard:'map/icons/buoy-starboard.png' };
  var ICON_SRC_H = 96;                                                          // icon pictures are 96 px tall
  // icon scale by zoom: invisible when zoomed out, growing as the user zooms in (kept small on purpose)
  var ICON_STOPS = [[10.8,0],[11.5,0.05],[12,0.07],[13,0.10],[15,0.16],[17,0.24],[19,0.36]];
  var BUOY_MINZOOM = 10.8;
  var SRC = 'port-features';
  function iconScale(z){
    if(z<=ICON_STOPS[0][0]) return 0;
    for(var i=1;i<ICON_STOPS.length;i++){
      if(z<=ICON_STOPS[i][0]){ var a=ICON_STOPS[i-1], b=ICON_STOPS[i], t=(z-a[0])/(b[0]-a[0]); return a[1]+(b[1]-a[1])*t; }
    }
    return ICON_STOPS[ICON_STOPS.length-1][1];
  }
  function iconPx(z){ return iconScale(z)*ICON_SRC_H; }
  function isBuoy(f){ var c=f.properties.cls; return c==='port' || c==='starboard'; }
  function abs(rel){ try{ return new URL(rel, document.baseURI).href; }catch(e){ return rel; } }

  /* ---------- data: validated once, cached (no re-parsing on every open) ---------- */
  var cache = null;
  function validCoord(c){ return c && c.length>=2 && isFinite(c[0]) && isFinite(c[1]) && Math.abs(c[0])<=180 && Math.abs(c[1])<=90; }
  function getData(){
    if(cache) return cache;
    var raw = window.SEATAXI_PORT_FEATURES, feats = [];
    if(raw && Array.isArray(raw.features)){
      raw.features.forEach(function(f, i){
        try{
          var g = f && f.geometry, p = (f && f.properties) || {};
          if(!g) return;
          var okPt = g.type==='Point' && validCoord(g.coordinates);
          var okLn = g.type==='LineString' && Array.isArray(g.coordinates) && g.coordinates.length>=2 && g.coordinates.every(validCoord);
          if(!okPt && !okLn){ if(window.console) console.warn('SeataxiPort: skipped unsupported/invalid feature', p.name); return; }
          feats.push({type:'Feature', properties:{id:String(p.id||('f'+i)), name:String(p.name||''), cls:p.cls||'landmark', type:p.type||'', label:String(p.label||p.name||'')}, geometry:g});
        }catch(e){ /* skip malformed feature */ }
      });
    }
    var bounds = null, pts = [], sewer = [];
    feats.forEach(function(f){
      var cs = f.geometry.type==='Point' ? [f.geometry.coordinates] : f.geometry.coordinates;
      cs.forEach(function(c){
        if(!bounds) bounds = [c[0],c[1],c[0],c[1]];
        else { bounds[0]=Math.min(bounds[0],c[0]); bounds[1]=Math.min(bounds[1],c[1]); bounds[2]=Math.max(bounds[2],c[0]); bounds[3]=Math.max(bounds[3],c[1]); }
      });
      if(f.geometry.type==='Point') pts.push(f); else if(f.properties.cls==='sewer') sewer.push(f);
    });
    cache = { fc:{type:'FeatureCollection', features:feats}, bounds:bounds, points:pts, sewers:sewer };
    return cache;
  }

  /* ---------- geometry helpers ---------- */
  function hav(aLng,aLat,bLng,bLat){
    var R=6371008.8, rad=Math.PI/180, dLat=(bLat-aLat)*rad, dLng=(bLng-aLng)*rad;
    var x=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(aLat*rad)*Math.cos(bLat*rad)*Math.sin(dLng/2)*Math.sin(dLng/2);
    return 2*R*Math.asin(Math.sqrt(x));
  }
  function lineLength(cs){ var s=0; for(var i=1;i<cs.length;i++) s+=hav(cs[i-1][0],cs[i-1][1],cs[i][0],cs[i][1]); return s; }
  function lineMidpoint(cs){
    var half=lineLength(cs)/2, acc=0;
    for(var i=1;i<cs.length;i++){
      var seg=hav(cs[i-1][0],cs[i-1][1],cs[i][0],cs[i][1]);
      if(acc+seg>=half && seg>0){ var t=(half-acc)/seg; return [cs[i-1][0]+(cs[i][0]-cs[i-1][0])*t, cs[i-1][1]+(cs[i][1]-cs[i-1][1])*t]; }
      acc+=seg;
    }
    return cs[0];
  }
  function distToSeg(px,py,ax,ay,bx,by){
    var dx=bx-ax, dy=by-ay, l2=dx*dx+dy*dy, t=l2?((px-ax)*dx+(py-ay)*dy)/l2:0;
    t=Math.max(0,Math.min(1,t));
    var cx=ax+t*dx, cy=ay+t*dy; return Math.sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
  }
  function fmtLat(v){ return v.toFixed(6); }                // signed decimal degrees, 6 dp, e.g. -6.820465
  function fmtLen(m){ return Math.round(m)+' m · '+(m/1000).toFixed(2)+' km'; }

  /* ---------- port-channel route: through the middle of each starboard/port buoy pair ---------- */
  // Gates = (starboard n, port n+1). Port buoy 20 has no numbered partner: the un-numbered green buoy ("west ferry") is its pair.
  function channelGates(){
    var d = getData(), stb = {}, unnumbered = [], ports = [];
    d.points.forEach(function(f){
      var n = /(\d+)\s*$/.exec(f.properties.name), num = n ? parseInt(n[1],10) : null;
      if(f.properties.cls==='starboard'){ if(num!=null) stb[num]=f.geometry.coordinates; else unnumbered.push(f.geometry.coordinates); }
      else if(f.properties.cls==='port' && num!=null) ports.push({n:num, c:f.geometry.coordinates});
    });
    ports.sort(function(a,b){ return a.n-b.n; });
    var gates = [];
    ports.forEach(function(p){
      var s = stb[p.n-1];
      if(!s){                                              // fall back to the nearest un-numbered green buoy within 600 m
        var best=null, bd=600;
        unnumbered.forEach(function(u){ var dd=hav(u[0],u[1],p.c[0],p.c[1]); if(dd<bd){ bd=dd; best=u; } });
        s = best;
      }
      if(s) gates.push([(s[0]+p.c[0])/2, (s[1]+p.c[1])/2]);
    });
    return gates;                                          // ordered from the sea (north) towards the harbour (south)
  }
  // Redraws the OSM "Dar es Salaam ⇔ Zanzibar" line so it runs through the gate mid-points; Dar–Kigamboni and all other
  // ferry lines are left exactly as they are.
  function patchMarine(fc){
    try{
      if(!fc || !Array.isArray(fc.features)) return fc;
      var gates = channelGates();
      if(gates.length<2) return fc;
      var first = gates[0];
      fc.features.forEach(function(f){
        var p = f.properties || {};
        if(!(f.geometry && f.geometry.type==='LineString' && p.k==='ferry' && /zanzibar/i.test(p.n||''))) return;
        var cs = f.geometry.coordinates, seaward = [];
        for(var i=0;i<cs.length;i++) if(cs[i][1] > first[1]) seaward.push(cs[i]);     // original points beyond the first gate (towards Zanzibar)
        f.geometry.coordinates = gates.slice().reverse().concat(seaward);              // harbour -> sea, same direction as the original
      });
    }catch(e){ if(window.console) console.warn('SeataxiPort.patchMarine:', e); }
    return fc;
  }

  /* ---------- MapLibre style fragment ---------- */
  function styleParts(P){
    var d = getData();
    var isSewer = ['==',['get','cls'],'sewer'];
    var none = ['==',['get','id'],''];
    var sizeExpr = ['interpolate',['linear'],['zoom']];
    ICON_STOPS.forEach(function(s){ sizeExpr.push(s[0], s[1]); });
    var sources = {}; sources[SRC] = {type:'geojson', data:d.fc};
    var layers = [
      // thin white casing so the black dots stay readable on sea, land and in dark mode (the dotted line itself is #000000 @ 100%)
      {id:'port-sewer-casing', type:'line', source:SRC, filter:isSewer, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':'#FFFFFF','line-opacity':0.75,'line-width':7}},
      {id:'port-sewer-select', type:'line', source:SRC, filter:none, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':'#FFC107','line-opacity':0.9,'line-width':12}},
      // dotted: a (near) zero-length dash with round caps = a round dot; spacing = 2.1 x line width
      {id:'port-sewer', type:'line', source:SRC, filter:isSewer, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':COLORS.sewer,'line-opacity':1,'line-width':3.5,'line-dasharray':[0.1,2]}},
      // buoys = the supplied red / green buoy pictures; tiny when zoomed out (gone below ~z10.8), bigger as you zoom in
      {id:'port-buoy', type:'symbol', source:SRC, minzoom:BUOY_MINZOOM,
        filter:['all',['==',['geometry-type'],'Point'],['in',['get','cls'],['literal',['port','starboard']]]],
        layout:{'icon-image':['match',['get','cls'],'port','buoy-port','buoy-starboard'],
                'icon-size':sizeExpr, 'icon-allow-overlap':true, 'icon-ignore-placement':true, 'icon-anchor':'center'}},
      {id:'port-select-ring', type:'circle', source:SRC, filter:none,
        paint:{'circle-radius':['interpolate',['linear'],['zoom'],8,9,15,14,18,19],'circle-color':'rgba(255,193,7,0.18)',
               'circle-stroke-color':'#FFC107','circle-stroke-width':3}}
    ];
    return {sources:sources, layers:layers};
  }
  function loadIcons(map){
    var ready = {};
    function put(id, img){
      try{ if(map.hasImage(id)) map.removeImage(id); map.addImage(id, img); ready[id] = true; }
      catch(e){ if(window.console) console.warn('SeataxiPort icon:', e); }
    }
    // until a picture has loaded, answer "missing image" with a transparent pixel (no console noise, nothing drawn)
    map.on('styleimagemissing', function(e){
      var id = e && e.id;
      if(id && /^buoy-/.test(id) && !map.hasImage(id)){ try{ map.addImage(id, {width:1, height:1, data:new Uint8Array(4)}); }catch(err){} }
    });
    function add(){
      Object.keys(ICON_FILES).forEach(function(k){
        var img = new Image();
        img.onload = function(){ put('buoy-'+k, img); };
        img.onerror = function(){ if(window.console) console.warn('SeataxiPort: missing icon', ICON_FILES[k]); };
        img.src = abs(ICON_FILES[k]);
      });
    }
    if(map.loaded && map.loaded()) add(); else map.once('load', add);
  }

  /* ---------- collision-free labels ---------- */
  function createLabelManager(map, o){
    o = o || {};
    var items = [], obstacles = [], sorted = true, raf = 0, destroyed = false;
    var ctx2d = null; try{ ctx2d = document.createElement('canvas').getContext('2d'); }catch(e){}
    function textW(text, italic){
      if(ctx2d){ ctx2d.font = (italic?'italic 600':'700')+' 11px sans-serif'; return ctx2d.measureText(text).width + 6; }
      return text.length*6.4 + 6;
    }
    function add(it){ it.w = textW(it.text, it.italic) + (it.padW||0); it.h = it.h || 14; items.push(it); sorted = false; schedule(); return it; }
    function addObstacle(ob){ obstacles.push(ob); }
    function schedule(){ if(raf || destroyed) return; raf = requestAnimationFrame(function(){ raf = 0; update(); }); }
    function hit(r, list, pad){
      for(var i=0;i<list.length;i++){ var b=list[i];
        if(r[0] < b[2]+pad && r[2] > b[0]-pad && r[1] < b[3]+pad && r[3] > b[1]-pad) return true; }
      return false;
    }
    function update(){
      if(destroyed) return;
      if(!sorted){ items.sort(function(a,b){ return b.pri-a.pri; }); sorted = true; }
      var z = map.getZoom(), c = map.getContainer(), W = c.clientWidth, H = c.clientHeight, acc = [];
      obstacles.forEach(function(ob){
        var s = ob.sizeFn ? ob.sizeFn(z) : {hw:ob.hw, hh:ob.hh}; if(!s) return;
        var p = map.project([ob.lng, ob.lat]);
        if(p.x < -80 || p.x > W+80 || p.y < -80 || p.y > H+80) return;
        acc.push([p.x-s.hw, p.y-s.hh, p.x+s.hw, p.y+s.hh]);
      });
      items.forEach(function(it){
        var show = false;
        it.rect = null;
        if(z >= it.z){
          var p = map.project([it.lng, it.lat]);
          if(!(p.x < -100 || p.x > W+100 || p.y < -40 || p.y > H+40)){
            var dy = it.dyFn ? it.dyFn(z) : (it.dy||0);
            var r = [p.x - it.w/2, p.y + dy, p.x + it.w/2, p.y + dy + it.h];
            if(!hit(r, acc, 2)){
              show = true; it.rect = r; acc.push(r);
              if(it.dyFn && it.marker && Math.abs((it._off||0)-dy) > 0.5){ it._off = dy; it.marker.setOffset([0, dy]); }
              if(it.fade){                                  // faint when first visible, clearer as the user zooms in on the area
                var op = Math.max(it.fade.min, Math.min(1, it.fade.min + (z-it.z)*(1-it.fade.min)/it.fade.span));
                if(Math.abs(op-(it._op||0)) > 0.02){ it.el.style.opacity = op; it._op = op; }
              }
            }
          }
        }
        if(show !== it._shown){ it.el.style.display = show ? 'block' : 'none'; it._shown = show; }
      });
    }
    map.on('move', schedule); map.on('resize', schedule);
    function destroy(){ destroyed = true; try{ map.off('move', schedule); map.off('resize', schedule); }catch(e){} }
    return {add:add, addObstacle:addObstacle, update:schedule, items:items, destroy:destroy};
  }

  /* ---------- UI ---------- */
  function el(tag, css, text){ var e=document.createElement(tag); if(css) e.style.cssText=css; if(text!=null) e.textContent=text; return e; }
  var SURF = 'background:var(--sx-surface,var(--surface,#fff));color:var(--sx-text,var(--text,#0B2A4A));box-shadow:var(--sx-shadow,0 4px 14px rgba(8,30,56,.22));';
  var legendOpen = false;                                  // remembered for the session

  function attach(map, ctx){
    var d = getData();
    if(!d.fc.features.length) return null;
    ctx = ctx || {};
    var tx = ctx.tx || function(k, def){ return def; };
    var P = ctx.P || {label:'#0C1E2E', halo:'#FFFFFF', ferry:'#0E4C86'};
    var overlay = ctx.overlay, markers = ctx.markers || [];
    var typeText = {
      berth: tx('tyBerth','Berth'), port: tx('tyPort','Port Buoy'), starboard: tx('tyStbd','Starboard Buoy'), sewer: tx('tySewer','Sewer Line'),
      ferry: tx('tyFerry','Ferry'), wharf: tx('tyWharf','Wharf / Pier / Jetty'), landmark: tx('tyLand','Landmark')
    };
    var mgr = ctx.labelMgr || createLabelManager(map);
    var ownMgr = !ctx.labelMgr;
    loadIcons(map);

    /* labels: buoys = NUMBER only; landmarks = name only (NO marker), faint at first and clearer as you zoom in; sewer = "Sewer" */
    var LBL = 'pointer-events:none;font:700 11px/1.2 sans-serif;color:'+P.label+';text-shadow:0 0 3px '+P.halo+',0 0 3px '+P.halo+',0 0 3px '+P.halo+';white-space:nowrap;display:none;';
    function addLabel(f, lng, lat, opt){
      var e = el('div', (opt.css||LBL), opt.text);
      var m = new maplibregl.Marker({element:e, anchor:(opt.anchor||'top'), offset:[0, opt.anchor==='center' ? 0 : (opt.dy||0)]}).setLngLat([lng,lat]).addTo(map);
      markers.push(m);
      return mgr.add({el:e, marker:m, text:opt.text, lng:lng, lat:lat, z:opt.z, pri:opt.pri, dy:opt.dy, dyFn:opt.dyFn, fade:opt.fade, kind:opt.kind, feature:f, h:opt.h, padW:opt.padW});
    }
    // berths: small numbered chips centred on their position (no dot), only when zoomed in
    var BERTH_CSS = 'pointer-events:none;font:800 11px/18px sans-serif;color:#fff;background:linear-gradient(135deg,#0A2A4D,#134377);border:1.5px solid #fff;border-radius:9px;padding:0 6px;min-width:6px;text-align:center;box-shadow:0 2px 6px rgba(8,30,56,.4);white-space:nowrap;display:none;';
    var buoyDy = function(z){ return iconPx(z)/2 + 4; };      // number sits just under the buoy picture (clear of its own icon box)
    d.fc.features.forEach(function(f){
      var c = f.properties.cls, g = f.geometry;
      if(g.type==='Point' && isBuoy(f)){
        addLabel(f, g.coordinates[0], g.coordinates[1], {text:f.properties.label, z:12.6, pri:60, dyFn:buoyDy, kind:'buoy'});
        mgr.addObstacle({lng:g.coordinates[0], lat:g.coordinates[1], sizeFn:function(z){ var h=iconPx(z); return h>=3 ? {hw:h*0.47, hh:h/2} : null; }});
      } else if(g.type==='Point' && c==='berth'){
        addLabel(f, g.coordinates[0], g.coordinates[1], {text:f.properties.label, z:14.2, pri:45, anchor:'center', dy:-9, h:18, padW:14, css:BERTH_CSS, fade:{min:0.55, span:1.2}, kind:'berth'});
      } else if(g.type==='Point'){
        var big = /\b(port|terminal|wharf|jetty|pier|ferry)\b/i.test(f.properties.name);
        addLabel(f, g.coordinates[0], g.coordinates[1], {text:f.properties.label, z:12.4, pri:big?35:30, dy:0, fade:{min:0.28, span:3.2}, kind:'land'});
      } else if(c==='sewer'){
        var mid = lineMidpoint(g.coordinates);
        addLabel(f, mid[0], mid[1], {text:f.properties.name, z:12.6, pri:50, dy:6, kind:'sewer'});
      }
    });
    mgr.update();

    /* info panel (top-left, clear of the right-hand controls and the bottom HUD) */
    var panel = el('div','position:absolute;left:12px;right:72px;top:calc(var(--safe-top,0px) + 88px);max-width:340px;padding:12px 14px;border-radius:20px;font:600 13px/1.55 sans-serif;display:none;z-index:4;'+SURF);
    overlay.appendChild(panel);
    var selFilterNone = ['==',['get','id'],''];
    function row(label, val){
      var r = el('div','display:flex;gap:6px;');
      r.appendChild(el('span','opacity:.7;min-width:78px;', label+':'));
      r.appendChild(el('span','font-weight:700;word-break:break-word;', val));
      return r;
    }
    function hidePanel(){
      panel.style.display = 'none';
      map.setFilter('port-select-ring', selFilterNone); map.setFilter('port-sewer-select', selFilterNone);
    }
    function showFeature(f){
      var p = f.properties, g = f.geometry, c = p.cls;
      panel.innerHTML = '';
      var head = el('div','display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:2px;');
      var title = el('div','flex:1;display:flex;gap:8px;align-items:flex-start;');
      if(COLORS[c]) title.appendChild(el('span','flex:none;margin-top:3px;width:12px;height:12px;border-radius:50%;background:'+COLORS[c]+';border:2px solid #fff;box-shadow:0 0 0 1px rgba(0,0,0,.35);'));
      title.appendChild(el('div','font-weight:800;font-size:14px;word-break:break-word;', p.name));
      var x = el('button','flex:none;width:44px;height:44px;margin:-10px -12px 0 0;border:0;background:transparent;color:inherit;font-size:18px;', '✕');
      x.setAttribute('aria-label', tx('close','Close')); x.onclick = hidePanel;
      head.appendChild(title); head.appendChild(x); panel.appendChild(head);
      panel.appendChild(row(tx('ptName','Name'), p.name));
      panel.appendChild(row(tx('ptType','Type'), typeText[c] || p.type));
      if(g.type==='Point'){
        panel.appendChild(row(tx('ptLat','Latitude'), fmtLat(g.coordinates[1])));
        panel.appendChild(row(tx('ptLng','Longitude'), fmtLat(g.coordinates[0])));
        map.setFilter('port-select-ring', ['==',['get','id'],p.id]); map.setFilter('port-sewer-select', selFilterNone);
      } else {
        var cs = g.coordinates, a = cs[0], b = cs[cs.length-1];
        panel.appendChild(row(tx('ptStart','Start'), fmtLat(a[1])+', '+fmtLat(a[0])));
        panel.appendChild(row(tx('ptEnd','End'), fmtLat(b[1])+', '+fmtLat(b[0])));
        panel.appendChild(row(tx('ptLength','Length'), fmtLen(lineLength(cs))));
        map.setFilter('port-sewer-select', ['==',['get','id'],p.id]); map.setFilter('port-select-ring', selFilterNone);
      }
      panel.style.display = 'block';
    }

    /* touch picking in SCREEN space: buoy icons (generous radius), visible landmark names, then the sewer line */
    function onClick(e){
      try{
        var z = map.getZoom(), best = null, bestD = 1e9;
        if(z >= BUOY_MINZOOM){
          var rad = Math.max(24, iconPx(z)/2 + 10);
          d.points.forEach(function(f){
            if(!isBuoy(f)) return;
            var s = map.project(f.geometry.coordinates), dx = s.x-e.point.x, dy = s.y-e.point.y, dd = Math.sqrt(dx*dx+dy*dy);
            if(dd<=rad && dd<bestD){ bestD=dd; best=f; }
          });
        }
        if(best){ showFeature(best); return; }
        mgr.items.forEach(function(it){                       // landmark names that are currently visible
          if((it.kind!=='land' && it.kind!=='berth') || !it._shown || !it.rect) return;
          var r = it.rect, pad = 10;
          if(e.point.x>=r[0]-pad && e.point.x<=r[2]+pad && e.point.y>=r[1]-pad && e.point.y<=r[3]+pad){
            var dd = Math.abs(e.point.x-(r[0]+r[2])/2) + Math.abs(e.point.y-(r[1]+r[3])/2);
            if(dd<bestD){ bestD=dd; best=it.feature; }
          }
        });
        if(best){ showFeature(best); return; }
        var sBest = null, sD = 1e9;
        d.sewers.forEach(function(f){
          var cs = f.geometry.coordinates;
          for(var i=1;i<cs.length;i++){
            var A = map.project(cs[i-1]), B = map.project(cs[i]);
            var dd = distToSeg(e.point.x,e.point.y,A.x,A.y,B.x,B.y);
            if(dd<sD){ sD=dd; sBest=f; }
          }
        });
        if(sBest && sD<=20){ showFeature(sBest); return; }
        hidePanel();
      }catch(err){ if(window.console) console.warn('SeataxiPort click:', err); }
    }
    map.on('click', onClick);

    /* "View Port Features" = fit all imported features. Camera only: never touches the GPS/vessel/navigation data. */
    function fitAll(){
      if(!d.bounds) return;
      if(ctx.setFollow) ctx.setFollow(false);            // stop auto-recentre; user taps ◎ to follow again
      var el0 = map.getContainer(), w = el0.clientWidth, h = el0.clientHeight;
      var hudH = (ctx.hud && ctx.hud.offsetHeight) || 70;
      var pad = {
        top: Math.min(120, h*0.2), bottom: Math.min(hudH+80, h*0.3),
        left: Math.min(36, w*0.1), right: Math.min(84, w*0.2)
      };
      map.fitBounds([[d.bounds[0],d.bounds[1]],[d.bounds[2],d.bounds[3]]], {padding:pad, maxZoom:17, duration:700});
    }
    if(ctx.ctrls){
      var fb = el('button','width:46px;height:46px;border:0;border-radius:15px;margin-top:10px;display:flex;align-items:center;justify-content:center;padding:0;'+SURF, '');
      fb.innerHTML = '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="5" r="2.4" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7.4V21M7.5 11.5h9M4 14c0 4 3.5 7 8 7s8-3 8-7M4 14l-1.6 2.2M20 14l1.6 2.2" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      var fitLabel = tx('portFit','View Port Features');
      fb.title = fitLabel; fb.setAttribute('aria-label', fitLabel); fb.onclick = fitAll;
      ctx.ctrls.appendChild(fb);
    }

    /* compact, collapsible legend (bottom-left, above the scale bar and the HUD) */
    var legend = el('div','position:absolute;left:12px;bottom:calc(var(--safe-bottom,0px) + var(--hud-h,56px) + 6px);z-index:3;max-width:calc(100% - 90px);');
    var legBtn = el('button','border:0;border-radius:17px;padding:0 13px;height:32px;font:800 12px sans-serif;display:block;'+SURF);
    var legBody = el('div','margin-bottom:6px;padding:8px 10px;border-radius:14px;font:600 11.5px/1.35 sans-serif;'+SURF);
    function legRow(swatch, text){
      var r = el('div','display:flex;align-items:center;gap:8px;padding:3px 0;');
      var box = el('span','flex:none;width:28px;display:flex;justify-content:center;'); box.appendChild(swatch);
      r.appendChild(box); r.appendChild(el('span','', text)); legBody.appendChild(r);
    }
    function buoyImg(k){ var i = el('img','display:block;height:22px;width:auto;'); i.src = abs(ICON_FILES[k]); i.alt = ''; return i; }
    legRow(buoyImg('port'),      tx('legPort','Red buoy — Port Buoy'));
    legRow(buoyImg('starboard'), tx('legStbd','Green buoy — Starboard Buoy'));
    legRow(el('span','display:block;width:28px;height:0;border-top:4px dotted '+COLORS.sewer+';'), tx('legSewer','Black dotted line — Sewer'));
    legRow(el('span','display:block;width:28px;height:0;border-top:3px dashed '+(P.ferry||'#0B3D75')+';'), tx('legRoute','Blue dashed line — Port channel route'));
    legRow(el('span','display:block;font:800 10px/16px sans-serif;color:#fff;background:#0A2A4D;border:1.5px solid #fff;border-radius:8px;padding:0 6px;box-shadow:0 1px 4px rgba(0,0,0,.4);','7'), tx('legBerth','Numbered chip — Berth'));
    function syncLegend(){
      legBody.style.display = legendOpen ? 'block' : 'none';
      legBtn.textContent = (legendOpen ? '▾ ' : '▸ ') + tx('legTitle','Legend');
      legBtn.setAttribute('aria-expanded', legendOpen ? 'true' : 'false');
    }
    legBtn.onclick = function(){ legendOpen = !legendOpen; syncLegend(); };
    // touching anywhere on the map closes the legend
    function closeLegend(){ if(legendOpen){ legendOpen = false; syncLegend(); } }
    var mapBox = map.getContainer();
    mapBox.addEventListener('pointerdown', closeLegend, true);
    legend.appendChild(legBody); legend.appendChild(legBtn); overlay.appendChild(legend); syncLegend();

    function destroy(){
      try{ map.off('click', onClick); mapBox.removeEventListener('pointerdown', closeLegend, true); if(ownMgr) mgr.destroy(); }catch(e){}
    }
    return {fitAll:fitAll, destroy:destroy, hidePanel:hidePanel};
  }

  window.SeataxiPort = {
    styleParts:styleParts, attach:attach, patchMarine:patchMarine, createLabelManager:createLabelManager, colors:COLORS,
    _internals:{ getData:getData, lineLength:lineLength, fmtLen:fmtLen, channelGates:channelGates, iconPx:iconPx }       // used by scripts/test-port-features.mjs
  };
})();
