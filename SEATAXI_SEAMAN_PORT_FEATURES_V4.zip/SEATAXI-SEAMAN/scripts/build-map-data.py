#!/usr/bin/env python3
"""
SEATAXI map data builder (pure Python 3, no third-party packages).

Input  : GeoJSON files exported by `osmium export` (see build-map-data.sh)
Output : compact files in www/map/data/ that the in-app offline map loads:
           land.geojson    land / sea polygons built from OSM coastline
           coast.geojson   coastline as lines
           roads.geojson   main roads
           water.geojson   lakes / rivers
           buildings.geojson  buildings (small port-core area only)
           marine.geojson  seamarks, piers, breakwaters, ferry routes, ...
           labels.json     place + marine names (drawn as HTML labels, so no
                           font files are needed -> fully offline)
           meta.json       bbox + build info

Usage: build-map-data.py WORKDIR OUTDIR west,south,east,north
"""
import json, math, os, sys, datetime

W = S = E = N = 0.0
ROUND = 5


# ---------------------------------------------------------------- helpers
def load_features(path):
    if not os.path.exists(path):
        print(f"  (missing {os.path.basename(path)} - skipped)")
        return []
    with open(path, "r", encoding="utf-8") as f:
        text = f.read().strip()
    if not text:
        return []
    try:
        data = json.loads(text)
        if data.get("type") == "FeatureCollection":
            return data.get("features", [])
        if data.get("type") == "Feature":
            return [data]
    except json.JSONDecodeError:
        pass
    feats = []
    for line in text.splitlines():  # GeoJSON-seq fallback
        line = line.strip().lstrip("\x1e")
        if line:
            try:
                feats.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return feats


def rpt(p):
    return [round(p[0], ROUND), round(p[1], ROUND)]


def round_geom(g):
    t = g["type"]
    c = g["coordinates"]
    if t == "Point":
        return {"type": t, "coordinates": rpt(c)}
    if t in ("LineString", "MultiPoint"):
        return {"type": t, "coordinates": dedupe([rpt(p) for p in c])}
    if t in ("Polygon", "MultiLineString"):
        return {"type": t, "coordinates": [dedupe([rpt(p) for p in r]) for r in c]}
    if t == "MultiPolygon":
        return {"type": t, "coordinates": [[dedupe([rpt(p) for p in r]) for r in poly] for poly in c]}
    return g


def dedupe(pts):
    out = []
    for p in pts:
        if not out or p != out[-1]:
            out.append(p)
    return out


def write_fc(path, feats):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"type": "FeatureCollection", "features": feats}, f, separators=(",", ":"))
    print(f"  wrote {os.path.basename(path)}: {len(feats)} features, {os.path.getsize(path)/1e6:.2f} MB")


def centroid(g):
    t = g["type"]
    if t == "Point":
        return g["coordinates"]
    if t == "LineString":
        pts = g["coordinates"]
        return pts[len(pts) // 2]
    if t == "Polygon":
        ring = g["coordinates"][0]
    elif t == "MultiPolygon":
        ring = g["coordinates"][0][0]
    elif t == "MultiLineString":
        ring = g["coordinates"][0]
    else:
        return None
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    return [(min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2]


def in_box(p):
    return W <= p[0] <= E and S <= p[1] <= N


# ---------------------------------------------------------------- coastline -> land
def merge_lines(lines):
    """Join directed coastline ways end-to-start into long chains / rings."""
    starts = {}
    for i, l in enumerate(lines):
        starts.setdefault(tuple(l[0]), []).append(i)
    has_pred = set()
    for l in lines:
        k = tuple(l[-1])
        if k in starts:
            for j in starts[k]:
                has_pred.add(j)
    used = [False] * len(lines)
    chains = []

    def follow(i):
        used[i] = True
        cur = list(lines[i])
        while True:
            nxt = None
            for j in starts.get(tuple(cur[-1]), []):
                if not used[j]:
                    nxt = j
                    break
            if nxt is None:
                break
            used[nxt] = True
            cur.extend(lines[nxt][1:])
        return cur

    for i in range(len(lines)):
        if not used[i] and i not in has_pred:
            chains.append(follow(i))
    for i in range(len(lines)):  # leftovers are pure cycles
        if not used[i]:
            chains.append(follow(i))
    return chains


def lb_clip(p, q):
    """Liang-Barsky: clip segment p->q to the bbox. Returns (a, b) or None."""
    x0, y0 = p
    dx, dy = q[0] - p[0], q[1] - p[1]
    t0, t1 = 0.0, 1.0
    for pp, qq in ((-dx, x0 - W), (dx, E - x0), (-dy, y0 - S), (dy, N - y0)):
        if pp == 0:
            if qq < 0:
                return None
        else:
            r = qq / pp
            if pp < 0:
                if r > t1:
                    return None
                t0 = max(t0, r)
            else:
                if r < t0:
                    return None
                t1 = min(t1, r)
    return (x0 + t0 * dx, y0 + t0 * dy), (x0 + t1 * dx, y0 + t1 * dy)


def clip_chain(pts):
    pieces, cur = [], []
    for i in range(len(pts) - 1):
        p, q = pts[i], pts[i + 1]
        r = lb_clip(p, q)
        if r is None:
            if cur:
                pieces.append(cur)
                cur = []
            continue
        a, b = r
        if cur and (abs(cur[-1][0] - a[0]) > 1e-12 or abs(cur[-1][1] - a[1]) > 1e-12):
            pieces.append(cur)
            cur = []
        if not cur:
            cur = [a]
        cur.append(b)
        if abs(b[0] - q[0]) > 1e-12 or abs(b[1] - q[1]) > 1e-12:  # exited the box
            pieces.append(cur)
            cur = []
    if cur:
        pieces.append(cur)
    return pieces


def tparam(p):
    """Position of a boundary point along the bbox perimeter, CCW, in [0,4)."""
    x = (p[0] - W) / (E - W)
    y = (p[1] - S) / (N - S)
    eps = 1e-7
    if abs(y) < eps:
        return x % 4
    if abs(x - 1) < eps:
        return 1 + y
    if abs(y - 1) < eps:
        return 2 + (1 - x)
    if abs(x) < eps:
        return 3 + (1 - y)
    return None


def corner(k):
    return [(W, S), (E, S), (E, N), (W, N)][k % 4]


def signed_area(ring):
    a = 0.0
    for i in range(len(ring) - 1):
        a += ring[i][0] * ring[i + 1][1] - ring[i + 1][0] * ring[i][1]
    return a / 2


def build_land(coast_feats):
    lines = []
    for f in coast_feats:
        g = f.get("geometry") or {}
        if g.get("type") == "LineString" and len(g["coordinates"]) > 1:
            lines.append([tuple(p) for p in g["coordinates"]])
        elif g.get("type") == "MultiLineString":
            for l in g["coordinates"]:
                if len(l) > 1:
                    lines.append([tuple(p) for p in l])
    print(f"  coastline ways: {len(lines)}")
    chains = merge_lines(lines)
    print(f"  merged chains/rings: {len(chains)}")

    out, pieces = [], []
    for ch in chains:
        closed = ch[0] == ch[-1] and len(ch) > 3
        if closed and all(in_box(p) for p in ch):
            ring = [list(p) for p in ch]
            a = signed_area(ring)
            kind = "land" if a > 0 else "sea"  # land is on the left of the way
            if a < 0:
                ring = ring[::-1]
            out.append({"type": "Feature", "properties": {"k": kind},
                        "geometry": {"type": "Polygon", "coordinates": [ring]}})
            continue
        if closed:  # rotate so the ring starts outside the box, then treat as open
            k = next((i for i, p in enumerate(ch) if not in_box(p)), None)
            if k is not None:
                ch = ch[k:-1] + ch[:k] + [ch[k]]
        pieces.extend(clip_chain(ch))

    # keep only pieces that begin and end on the bbox boundary
    P = []
    for pc in pieces:
        s, e = tparam(pc[0]), tparam(pc[-1])
        if s is None or e is None or len(pc) < 2:
            continue
        P.append({"pts": pc, "s": s, "e": e, "used": False})
    print(f"  open coastline pieces crossing the box: {len(P)}")

    for i, start in enumerate(P):
        if start["used"]:
            continue
        ring, cur, guard = [], start, 0
        while guard < len(P) + 2:
            guard += 1
            cur["used"] = True
            ring.extend(cur["pts"])
            tE = cur["e"]
            best, bd = None, 9.0
            for cand in P:
                if cand["used"] and cand is not start:
                    continue
                d = (cand["s"] - tE) % 4
                if d < bd:
                    best, bd = cand, d
            if best is None:
                break
            k = math.floor(tE) + 1
            while k < tE + bd - 1e-9:
                ring.append(list(corner(k)))
                k += 1
            if best is start:
                ring.append(ring[0])
                break
            cur = best
        if len(ring) >= 4 and ring[0] == ring[-1]:
            out.append({"type": "Feature", "properties": {"k": "land"},
                        "geometry": {"type": "Polygon", "coordinates": [[list(p) for p in ring]]}})
    return out


# ---------------------------------------------------------------- feature builders
HEX_UNUSED = None


def first_colour(tags):
    for k, v in tags.items():
        if k.startswith("seamark:") and k.endswith(":colour") and v:
            return v.split(";")[0].strip().lower()
    return ""


def has_light(tags):
    return any(k.startswith("seamark:light") for k in tags)


ZONE_TYPES = {"fairway", "recommended_track", "navigation_line", "restricted_area", "anchorage",
              "prohibited_area", "separation_zone", "two-way_route", "inshore_traffic_zone",
              "harbour", "harbour_basin", "berth", "small_craft_facility", "cable_area",
              "pipeline_area", "dredged_area", "military_area", "marine_farm", "precautionary_area"}


def build_marine(feats, labels):
    out = []
    for f in feats:
        g = f.get("geometry")
        pr = f.get("properties") or {}
        if not g:
            continue
        gt = g["type"]
        name = pr.get("seamark:name") or pr.get("name") or ""
        st = pr.get("seamark:type", "")
        k = None
        if st:
            if gt == "Point":
                k = "mark"
            else:
                if st not in ZONE_TYPES:
                    continue
                k = "zone"
        elif pr.get("man_made") in ("pier", "breakwater", "groyne", "quay"):
            k = pr["man_made"]
        elif pr.get("man_made") == "lighthouse":
            k = "lighthouse"
        elif pr.get("route") == "ferry":
            k = "ferry"
        elif pr.get("amenity") == "ferry_terminal":
            k = "terminal"
        elif pr.get("leisure") == "marina":
            k = "marina"
        elif pr.get("landuse") == "harbour" or pr.get("harbour"):
            k = "harbour"
        elif pr.get("waterway") == "dock":
            k = "dock"
        elif pr.get("natural") == "reef":
            k = "reef"
        if not k:
            continue
        props = {"k": k}
        if st:
            props["t"] = st
            c = first_colour(pr)
            if c:
                props["c"] = c
            if has_light(pr):
                props["l"] = 1
        if name:
            props["n"] = name
        out.append({"type": "Feature", "properties": props, "geometry": round_geom(g)})
        if name and k in ("mark", "pier", "breakwater", "lighthouse", "terminal", "marina", "harbour", "dock", "reef", "quay"):
            c = centroid(g)
            if c:
                labels.append({"n": name, "lat": round(c[1], ROUND), "lng": round(c[0], ROUND), "k": "m", "r": 5})
    return out


PLACE_RANK = {"city": 1, "island": 2, "town": 2, "suburb": 3, "quarter": 3, "village": 4,
              "neighbourhood": 4, "hamlet": 4, "islet": 4, "locality": 5}


def build_places(feats):
    labels = []
    for f in feats:
        pr = f.get("properties") or {}
        g = f.get("geometry")
        name = pr.get("name:en") or pr.get("name")
        rank = PLACE_RANK.get(pr.get("place"))
        if not name or not g or not rank:
            continue
        c = centroid(g)
        if not c or not in_box(c):
            continue
        labels.append({"n": name, "lat": round(c[1], ROUND), "lng": round(c[0], ROUND), "k": "p", "r": rank})
    return labels


def build_simple(feats, keep):
    out = []
    for f in feats:
        g = f.get("geometry")
        pr = f.get("properties") or {}
        if not g:
            continue
        props = {}
        for kname, fn in keep.items():
            v = fn(pr)
            if v not in (None, ""):
                props[kname] = v
        out.append({"type": "Feature", "properties": props, "geometry": round_geom(g)})
    return out


# ---------------------------------------------------------------- main
def main():
    global W, S, E, N
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    work, outdir, bbox = sys.argv[1], sys.argv[2], sys.argv[3]
    W, S, E, N = [float(x) for x in bbox.split(",")]
    os.makedirs(outdir, exist_ok=True)
    print(f"Building map data for bbox W{W} S{S} E{E} N{N}")

    print("[land + coastline]")
    coast = load_features(os.path.join(work, "coast.geojson"))
    land = build_land(coast)
    n_land = sum(1 for f in land if f["properties"]["k"] == "land")
    if n_land == 0:
        print("::warning::No land polygons could be built from the coastline - the map will show sea only.")
    write_fc(os.path.join(outdir, "land.geojson"), [
        {"type": "Feature", "properties": f["properties"], "geometry": round_geom(f["geometry"])} for f in land])
    write_fc(os.path.join(outdir, "coast.geojson"),
             [{"type": "Feature", "properties": {}, "geometry": round_geom(f["geometry"])}
              for f in coast if f.get("geometry")])

    print("[roads]")
    roads = build_simple(load_features(os.path.join(work, "roads.geojson")),
                         {"h": lambda p: p.get("highway", "").replace("_link", "")})
    write_fc(os.path.join(outdir, "roads.geojson"), roads)

    print("[water]")
    water = build_simple(load_features(os.path.join(work, "water.geojson")),
                         {"k": lambda p: "line" if p.get("waterway") else "area"})
    write_fc(os.path.join(outdir, "water.geojson"), water)

    print("[buildings]")
    b = build_simple(load_features(os.path.join(work, "buildings.geojson")), {})
    write_fc(os.path.join(outdir, "buildings.geojson"), b)

    print("[marine + labels]")
    labels = build_places(load_features(os.path.join(work, "places.geojson")))
    marine = build_marine(load_features(os.path.join(work, "marine.geojson")), labels)
    write_fc(os.path.join(outdir, "marine.geojson"), marine)

    seen, uniq = set(), []
    for l in labels:
        key = (l["n"].lower(), l["k"])
        if key not in seen:
            seen.add(key)
            uniq.append(l)
    with open(os.path.join(outdir, "labels.json"), "w", encoding="utf-8") as f:
        json.dump(uniq, f, ensure_ascii=False, separators=(",", ":"))
    print(f"  wrote labels.json: {len(uniq)} labels")

    meta = {"bbox": [W, S, E, N], "built": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "landPolygons": n_land, "roads": len(roads), "marine": len(marine), "labels": len(uniq),
            "source": "OpenStreetMap contributors (ODbL), via Geofabrik"}
    with open(os.path.join(outdir, "meta.json"), "w") as f:
        json.dump(meta, f)
    total = sum(os.path.getsize(os.path.join(outdir, x)) for x in os.listdir(outdir))
    print(f"Done. Total map data: {total/1e6:.1f} MB")


if __name__ == "__main__":
    main()
