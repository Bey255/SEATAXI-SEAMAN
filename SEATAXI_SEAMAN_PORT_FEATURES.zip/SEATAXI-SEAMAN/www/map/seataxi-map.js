/* SEATAXI offline map (MapLibre GL, local data only — no network calls).
   Loaded lazily: vendor/maplibre-gl.js + map/data/*.geojson are bundled in the APK.
   API:  SeataxiMap.open({stations, getVessel, dark, t, onClose}) -> Promise
         SeataxiMap.close()   SeataxiMap.isOpen()
   Rejects with Error('nodata'|'nolib') when the bundled map files are missing,
   so the caller can fall back to the old schematic.
   Port-channel buoys / sewer line / landmarks (from the KML) are drawn by map/seataxi-port.js
   when it is loaded; if it is missing the map works exactly as before. */
(function(){
  'use strict';
  var state = { open:false, map:null, overlay:null, timer:null, markers:[], labelEls:[], onClose:null, port:null };

  function abs(rel){ return new URL(rel, document.baseURI).href; }

  function loadScript(src){
    return new Promise(function(res, rej){
      var s = document.createElement('script'); s.src = src;
      s.onload = res; s.onerror = function(){ rej(new Error('nolib')); };
      document.head.appendChild(s);
    });
  }
  function loadCss(href){
    if(document.querySelector('link[data-seamap]')) return;
    var l = document.createElement('link'); l.rel='stylesheet'; l.href=href; l.setAttribute('data-seamap','1');
    document.head.appendChild(l);
  }
  function ensureLib(){
    if(window.maplibregl) return Promise.resolve();
    loadCss(abs('vendor/maplibre-gl.css'));
    return loadScript(abs('vendor/maplibre-gl.js'));
  }
  function fetchJson(rel){
    return fetch(abs(rel)).then(function(r){ if(!r.ok) throw new Error('nodata'); return r.json(); });
  }

  /* ---------- geometry helpers ---------- */
  function hav(aLat,aLng,bLat,bLng){
    var R=6371008.8, rad=Math.PI/180;
    var dLat=(bLat-aLat)*rad, dLng=(bLng-aLng)*rad;
    var x=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(aLat*rad)*Math.cos(bLat*rad)*Math.sin(dLng/2)*Math.sin(dLng/2);
    return 2*R*Math.asin(Math.sqrt(x));            // metres
  }
  function bearing(aLat,aLng,bLat,bLng){
    var rad=Math.PI/180, dL=(bLng-aLng)*rad;
    var y=Math.sin(dL)*Math.cos(bLat*rad);
    var x=Math.cos(aLat*rad)*Math.sin(bLat*rad)-Math.sin(aLat*rad)*Math.cos(bLat*rad)*Math.cos(dL);
    return (Math.atan2(y,x)/rad+360)%360;
  }
  function fmtDist(m){
    var nm=m/1852;
    return (nm<10?nm.toFixed(2):nm.toFixed(1))+' nm · '+(m<10000?(m/1000).toFixed(2):(m/1000).toFixed(1))+' km';
  }

  /* ---------- style ---------- */
  var COLOURS = ['match',['get','c'],
    'red','#D32F2F','green','#2E9E4F','yellow','#F2C200','white','#FFFFFF','black','#1B1B1B',
    'blue','#1976D2','orange','#F57C00','grey','#8A8F94','#B5179E'];

  function palette(dark){
    return dark ? {
      sea:'#0B2438', land:'#1B2A36', coast:'#4F7F9E', road:'#566B7C', roadMain:'#7F95A6',
      bld:'#2A3947', water:'#0B2438', pier:'#8EA2B3', ferry:'#5FA8E8', zone:'#D067C2', label:'#EAF1F7', halo:'#081826'
    } : {
      sea:'#BFDCEC', land:'#F3F0E8', coast:'#6A9BB8', road:'#FFFFFF', roadMain:'#F6D98A',
      bld:'#DED6CC', water:'#BFDCEC', pier:'#7B8794', ferry:'#0E4C86', zone:'#B5179E', label:'#0C1E2E', halo:'#FFFFFF'
    };
  }

  function buildStyle(P){
    var src = function(n){ return { type:'geojson', data: abs('map/data/'+n+'.geojson') }; };
    var isPt = ['==',['geometry-type'],'Point'];
    var isLine = ['==',['geometry-type'],'LineString'];
    var isPoly = ['==',['geometry-type'],'Polygon'];
    var st = {
      version:8,
      sources:{ land:src('land'), coast:src('coast'), roads:src('roads'), water:src('water'),
                bld:src('buildings'), marine:src('marine') },
      layers:[
        {id:'bg', type:'background', paint:{'background-color':P.sea}},
        {id:'land', type:'fill', source:'land', filter:['==',['get','k'],'land'], paint:{'fill-color':P.land}},
        {id:'sea-holes', type:'fill', source:'land', filter:['==',['get','k'],'sea'], paint:{'fill-color':P.sea}},
        {id:'water-area', type:'fill', source:'water', filter:['==',['get','k'],'area'], paint:{'fill-color':P.water}},
        {id:'water-line', type:'line', source:'water', filter:['==',['get','k'],'line'],
          paint:{'line-color':P.water,'line-width':['interpolate',['linear'],['zoom'],10,0.8,16,3]}},
        {id:'bld', type:'fill', source:'bld', minzoom:14.5, paint:{'fill-color':P.bld}},
        {id:'road-minor', type:'line', source:'roads', minzoom:12.5,
          filter:['in',['get','h'],['literal',['tertiary','unclassified','residential','living_street']]],
          paint:{'line-color':P.road,'line-width':['interpolate',['linear'],['zoom'],12.5,0.6,17,5]}},
        {id:'road-main', type:'line', source:'roads',
          filter:['in',['get','h'],['literal',['motorway','trunk','primary','secondary']]],
          paint:{'line-color':P.roadMain,'line-width':['interpolate',['linear'],['zoom'],9,0.8,17,8]}},
        {id:'coast', type:'line', source:'coast', paint:{'line-color':P.coast,'line-width':['interpolate',['linear'],['zoom'],8,0.6,17,2]}},
        {id:'marine-poly', type:'fill', source:'marine',
          filter:['all',isPoly,['in',['get','k'],['literal',['pier','quay','harbour','dock','marina']]]],
          paint:{'fill-color':P.pier,'fill-opacity':0.35}},
        {id:'marine-structure', type:'line', source:'marine',
          filter:['all',['in',['geometry-type'],['literal',['LineString','Polygon']]],
                  ['in',['get','k'],['literal',['pier','breakwater','groyne','quay']]]],
          paint:{'line-color':P.pier,'line-width':['interpolate',['linear'],['zoom'],11,1,17,6]}},
        {id:'ferry', type:'line', source:'marine', filter:['all',isLine,['==',['get','k'],'ferry']],
          paint:{'line-color':P.ferry,'line-width':1.6,'line-dasharray':[3,2]}},
        {id:'zones', type:'line', source:'marine', filter:['==',['get','k'],'zone'],
          paint:{'line-color':P.zone,'line-width':1.1,'line-dasharray':[4,3]}},
        {id:'mark-light', type:'circle', source:'marine', minzoom:11,
          filter:['all',isPt,['==',['get','l'],1]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],11,5,17,13],'circle-color':'rgba(255,220,0,0.25)',
                 'circle-stroke-color':'#F2C200','circle-stroke-width':1.2}},
        {id:'mark-hazard', type:'circle', source:'marine', minzoom:11,
          filter:['all',isPt,['in',['get','t'],['literal',['wreck','rock','obstruction']]]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],11,3,17,8],'circle-color':'#111111',
                 'circle-stroke-color':'#D32F2F','circle-stroke-width':2}},
        {id:'mark', type:'circle', source:'marine', minzoom:10,
          filter:['all',isPt,['==',['get','k'],'mark'],['!',['in',['get','t'],['literal',['wreck','rock','obstruction']]]]],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],10,2.5,14,5,17,9],'circle-color':COLOURS,
                 'circle-stroke-color':'#1B1B1B','circle-stroke-width':1.2}},
        {id:'lighthouse', type:'circle', source:'marine', minzoom:9,
          filter:['all',isPt,['==',['get','k'],'lighthouse']],
          paint:{'circle-radius':['interpolate',['linear'],['zoom'],9,4,17,10],'circle-color':'#F2C200',
                 'circle-stroke-color':'#1B1B1B','circle-stroke-width':1.5}}
      ]
    };
    // KML port features (buoys, sewer line, landmarks) go on top of the base map. Local data, no fetch.
    try{
      if(window.SeataxiPort){
        var pp = SeataxiPort.styleParts(P);
        Object.keys(pp.sources).forEach(function(k){ st.sources[k] = pp.sources[k]; });
        st.layers = st.layers.concat(pp.layers);
      }
    }catch(e){ if(window.console) console.warn('SeataxiMap: port layers skipped:', e); }
    return st;
  }

  /* ---------- UI ---------- */
  function el(tag, css, html){ var e=document.createElement(tag); if(css) e.style.cssText=css; if(html!=null) e.innerHTML=html; return e; }
  function btn(txt, title, onclick){
    var b = el('button',
      'width:44px;height:44px;border:0;border-radius:12px;background:var(--surface,#fff);color:var(--text,#0C1E2E);'+
      'font-size:20px;font-weight:700;box-shadow:0 2px 8px rgba(0,0,0,.25);margin-top:8px;display:block;', txt);
    b.title = title; b.setAttribute('aria-label', title); b.onclick = onclick; return b;
  }
  function pinEl(color, text){
    var d = el('div','display:flex;flex-direction:column;align-items:center;pointer-events:none;');
    d.appendChild(el('div','width:16px;height:16px;border-radius:50%;background:'+color+';border:3px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.5);'));
    d.appendChild(el('div','margin-top:2px;padding:1px 6px;border-radius:8px;background:rgba(255,255,255,.92);color:#0C1E2E;font:700 11px/1.3 sans-serif;white-space:nowrap;', text));
    return d;
  }
  function vesselEl(){
    var d = el('div','width:34px;height:34px;');
    d.innerHTML = '<svg viewBox="0 0 34 34" width="34" height="34"><circle cx="17" cy="17" r="15" fill="rgba(208,32,43,.18)"/>'+
      '<path d="M17 4 L26 28 L17 23 L8 28 Z" fill="#D0202B" stroke="#fff" stroke-width="2" stroke-linejoin="round"/></svg>';
    return d;
  }

  function open(opts){
    if(state.open) return Promise.resolve();
    opts = opts || {};
    var T = opts.t || {};
    var tx = function(k, d){ return T[k] || d; };

    return ensureLib().then(function(){
      return Promise.all([fetchJson('map/data/meta.json'), fetchJson('map/data/labels.json').catch(function(){ return []; })]);
    }).then(function(res){
      var meta = res[0], labels = res[1];
      var bbox = meta.bbox;                       // [w,s,e,n]
      var P = palette(!!opts.dark);

      var overlay = el('div','position:fixed;inset:0;z-index:9000;background:'+P.sea+';');
      overlay.className = 'seataxi-map-overlay';
      var mapDiv = el('div','position:absolute;inset:0;');
      overlay.appendChild(mapDiv);
      // keep the scale bar + attribution above the bottom HUD instead of underneath it (--hud-h is kept in sync in tick())
      overlay.appendChild(el('style','','.seataxi-map-overlay .maplibregl-ctrl-bottom-left,.seataxi-map-overlay .maplibregl-ctrl-bottom-right{bottom:calc(var(--safe-bottom,0px) + var(--hud-h,64px) + 20px)!important;}'));

      var top = el('div','position:absolute;left:0;right:0;top:0;padding:calc(var(--safe-top,0px) + 10px) 12px 10px;display:flex;align-items:center;justify-content:space-between;'+
        'background:linear-gradient(rgba(7,27,46,.65),rgba(7,27,46,0));color:#fff;pointer-events:none;');
      top.appendChild(el('div','font:800 16px/1.2 sans-serif;text-shadow:0 1px 3px rgba(0,0,0,.6);', tx('title','MAP')));
      var closeB = btn('✕', tx('close','Close'), function(){ close(); });
      closeB.style.marginTop='0'; closeB.style.pointerEvents='auto';
      top.appendChild(closeB);
      overlay.appendChild(top);

      var ctrls = el('div','position:absolute;right:12px;top:calc(var(--safe-top,0px) + 70px);');
      overlay.appendChild(ctrls);

      var hud = el('div','position:absolute;left:10px;right:10px;bottom:calc(var(--safe-bottom,0px) + 10px);padding:10px 12px;border-radius:14px;'+
        'background:var(--surface,#fff);color:var(--text,#0C1E2E);box-shadow:0 4px 16px rgba(0,0,0,.3);font:600 13px/1.5 sans-serif;');
      overlay.appendChild(hud);
      document.body.appendChild(overlay);

      var st = opts.stations || {};
      var dar = st.dar, kig = st.kigamboni;
      var center = [(dar.lng+kig.lng)/2, (dar.lat+kig.lat)/2];

      var map = new maplibregl.Map({
        container: mapDiv, style: buildStyle(P), center: center, zoom: 14.5, minZoom: 8, maxZoom: 19.5,
        maxBounds: [[bbox[0]-0.02,bbox[1]-0.02],[bbox[2]+0.02,bbox[3]+0.02]],
        attributionControl: false, pitchWithRotate: false, dragRotate: true, touchPitch: false, fadeDuration: 0
      });
      map.addControl(new maplibregl.AttributionControl({compact:true, customAttribution:'© OpenStreetMap contributors'}), 'bottom-right');
      map.addControl(new maplibregl.ScaleControl({maxWidth:90, unit:'nautical'}), 'bottom-left');

      state.map = map; state.overlay = overlay; state.open = true; state.onClose = opts.onClose || null;

      var follow = true;
      var followBtn;
      var setFollowUi = function(){ if(followBtn) followBtn.style.background = follow ? '#D0202B' : 'var(--surface,#fff)'; if(followBtn) followBtn.style.color = follow ? '#fff' : 'var(--text,#0C1E2E)'; };

      ctrls.appendChild(btn('+', 'Zoom in', function(){ map.zoomIn(); }));
      ctrls.appendChild(btn('−', 'Zoom out', function(){ map.zoomOut(); }));
      followBtn = btn('◎', tx('follow','Follow my position'), function(){
        follow = true; setFollowUi();
        var v = getV(); if(v) map.easeTo({center:[v.lng,v.lat], zoom: Math.max(map.getZoom(),15), bearing:0, duration:600});
      });
      ctrls.appendChild(followBtn);
      ctrls.appendChild(btn('N', tx('north','North up'), function(){ map.easeTo({bearing:0, duration:400}); }));
      setFollowUi();
      map.on('dragstart', function(e){ if(e && e.originalEvent){ follow = false; setFollowUi(); } });

      // station markers
      var mk = function(s, color, text){
        var m = new maplibregl.Marker({element: pinEl(color, text), anchor:'center'}).setLngLat([s.lng, s.lat]).addTo(map);
        state.markers.push(m);
      };
      mk(dar, '#0E4C86', tx('dar','DAR'));
      mk(kig, '#1E8E5A', tx('kigamboni','KIGAMBONI'));

      // text labels as HTML (no font files needed -> fully offline)
      var minZ = {1:8, 2:10, 3:12, 4:13.5, 5:14.5};
      labels.forEach(function(l){
        var d = el('div','pointer-events:none;font:700 11px/1.2 sans-serif;color:'+P.label+';text-shadow:0 0 3px '+P.halo+',0 0 3px '+P.halo+',0 0 3px '+P.halo+';white-space:nowrap;display:none;',
          (l.k==='m'?'':'')+l.n.replace(/</g,'&lt;'));
        if(l.k==='m') d.style.fontWeight='600', d.style.fontStyle='italic';
        var m = new maplibregl.Marker({element:d, anchor:'top', offset:[0,6]}).setLngLat([l.lng,l.lat]).addTo(map);
        state.markers.push(m);
        state.labelEls.push({el:d, z:minZ[l.r]||14});
      });
      var updLabels = function(){
        var z = map.getZoom();
        state.labelEls.forEach(function(o){ o.el.style.display = z>=o.z ? 'block':'none'; });
      };
      map.on('zoom', updLabels); updLabels();

      // port channel features from the KML: name labels, tap info, legend, "View Port Features" button.
      // Camera-only controls; never changes GPS / vessel / follow state except turning auto-follow off when the user asks to see the port.
      try{
        if(window.SeataxiPort){
          state.port = SeataxiPort.attach(map, { overlay:overlay, ctrls:ctrls, hud:hud, P:P, tx:tx, markers:state.markers,
            setFollow:function(v){ follow = v; setFollowUi(); } });
        }
      }catch(e){ if(window.console) console.warn('SeataxiMap: port features unavailable:', e); }

      // vessel
      var vMarker = new maplibregl.Marker({element: vesselEl(), rotationAlignment:'map', pitchAlignment:'map'});
      var vOn = false, lastHeading = 0, centered = false;
      function getV(){
        try{ var v = opts.getVessel && opts.getVessel(); return (v && v.lat!=null && v.lng!=null) ? v : null; }catch(e){ return null; }
      }
      function syncHud(){ try{ overlay.style.setProperty('--hud-h', hud.offsetHeight+'px'); }catch(e){} }
      function tick(){
        var v = getV();
        if(!v){
          hud.innerHTML = '<b>'+tx('noGps','Waiting for GPS…')+'</b>'; syncHud(); return;
        }
        if(!vOn){ vMarker.setLngLat([v.lng,v.lat]).addTo(map); vOn = true; } else vMarker.setLngLat([v.lng,v.lat]);
        if(v.heading!=null && !isNaN(v.heading) && (v.speedKn||0) > 0.5){ lastHeading = v.heading; }
        vMarker.setRotation(lastHeading);
        if(follow){
          if(!centered){ map.jumpTo({center:[v.lng,v.lat], zoom: 15.5}); centered = true; }
          else map.easeTo({center:[v.lng,v.lat], duration:900, easing:function(x){return x;}});
        }
        var dD = hav(v.lat,v.lng,dar.lat,dar.lng), dK = hav(v.lat,v.lng,kig.lat,kig.lng);
        hud.innerHTML =
          '<div style="display:flex;justify-content:space-between;gap:8px;"><span>→ <b>'+tx('dar','DAR')+'</b></span><span>'+fmtDist(dD)+' · '+Math.round(bearing(v.lat,v.lng,dar.lat,dar.lng))+'°</span></div>'+
          '<div style="display:flex;justify-content:space-between;gap:8px;"><span>→ <b>'+tx('kigamboni','KIGAMBONI')+'</b></span><span>'+fmtDist(dK)+' · '+Math.round(bearing(v.lat,v.lng,kig.lat,kig.lng))+'°</span></div>'+
          '<div style="margin-top:4px;font-weight:500;font-size:11px;opacity:.75;">'+v.lat.toFixed(5)+', '+v.lng.toFixed(5)+' — '+tx('notNav','Not for primary navigation. Check official charts.')+'</div>';
        syncHud();
      }
      state.timer = setInterval(tick, 1000);

      map.on('load', function(){
        var v = getV();
        if(!v){
          map.fitBounds([[Math.min(dar.lng,kig.lng),Math.min(dar.lat,kig.lat)],[Math.max(dar.lng,kig.lng),Math.max(dar.lat,kig.lat)]],
            {padding:90, maxZoom:16, duration:0});
          follow = false; setFollowUi();
        }
        tick();
      });
      map.on('error', function(e){ if(e && e.error && window.console) console.warn('SeataxiMap:', e.error.message || e.error); });
    }).catch(function(err){
      close();
      throw err;
    });
  }

  function close(){
    if(state.timer){ clearInterval(state.timer); state.timer = null; }
    try{ if(state.port) state.port.destroy(); }catch(e){}
    try{ state.markers.forEach(function(m){ m.remove(); }); }catch(e){}
    try{ if(state.map) state.map.remove(); }catch(e){}
    if(state.overlay && state.overlay.parentNode) state.overlay.parentNode.removeChild(state.overlay);
    var cb = state.onClose;
    state = { open:false, map:null, overlay:null, timer:null, markers:[], labelEls:[], onClose:null, port:null };
    if(cb){ try{ cb(); }catch(e){} }
  }

  window.SeataxiMap = { open:open, close:close, isOpen:function(){ return state.open; } };
})();
