/* SEATAXI port features layer (Dar es Salaam port channel) — local data only, works offline.
   Data:   window.SEATAXI_PORT_FEATURES  (map/port-features.js, generated from the KML by
           scripts/kml-to-geojson.mjs — never edited by hand)
   Used by map/seataxi-map.js:
     SeataxiPort.styleParts(P)        -> {sources, layers} merged into the MapLibre style
     SeataxiPort.attach(map, ctx)     -> adds name labels, tap info panel, legend and the
                                          "View Port Features" button; returns {fitAll, destroy}
   Colours (exact, per brief):  port buoy #FF0000 · starboard buoy #008000 · sewer line #000000 dotted. */
(function(){
  'use strict';

  var COLORS = {
    port:'#FF0000', starboard:'#008000', sewer:'#000000',
    ferry:'#1565C0', wharf:'#795548', landmark:'#7E57C2'     // neutral, none clash with red/green/black
  };
  var SRC = 'port-features';
  var BUOY_CLS = ['port','starboard'];
  var OTHER_CLS = ['ferry','wharf','landmark'];

  /* ---------- data: validated once, cached (no re-parsing on every open) ---------- */
  var cache = null;
  function validCoord(c){ return c && c.length>=2 && isFinite(c[0]) && isFinite(c[1]) && Math.abs(c[0])<=180 && Math.abs(c[1])<=90; }
  function getData(){
    if(cache) return cache;
    var raw = window.SEATAXI_PORT_FEATURES, feats = [];
    if(raw && Array.isArray(raw.features)){
      raw.features.forEach(function(f, i){
        try{
          var g = f && f.geometry, p = (f && f.properties) || {};
          if(!g) return;
          if(g.type==='Point' && validCoord(g.coordinates)){
            // fall through
          } else if(g.type==='LineString' && Array.isArray(g.coordinates) && g.coordinates.length>=2 && g.coordinates.every(validCoord)){
            // fall through
          } else { if(window.console) console.warn('SeataxiPort: skipped unsupported/invalid feature', p.name); return; }
          feats.push({type:'Feature', properties:{id:String(p.id||('f'+i)), name:String(p.name||''), cls:p.cls||'landmark', type:p.type||''}, geometry:g});
        }catch(e){ /* skip malformed feature */ }
      });
    }
    var bounds = null, pts = [], sewer = [];
    feats.forEach(function(f){
      var cs = f.geometry.type==='Point' ? [f.geometry.coordinates] : f.geometry.coordinates;
      cs.forEach(function(c){
        if(!bounds) bounds = [c[0],c[1],c[0],c[1]];
        else { bounds[0]=Math.min(bounds[0],c[0]); bounds[1]=Math.min(bounds[1],c[1]); bounds[2]=Math.max(bounds[2],c[0]); bounds[3]=Math.max(bounds[3],c[1]); }
      });
      if(f.geometry.type==='Point') pts.push(f); else if(f.properties.cls==='sewer') sewer.push(f);
    });
    cache = { fc:{type:'FeatureCollection', features:feats}, bounds:bounds, points:pts, sewers:sewer, byId:{} };
    feats.forEach(function(f){ cache.byId[f.properties.id] = f; });
    return cache;
  }

  /* ---------- geometry helpers ---------- */
  function hav(aLng,aLat,bLng,bLat){
    var R=6371008.8, rad=Math.PI/180, dLat=(bLat-aLat)*rad, dLng=(bLng-aLng)*rad;
    var x=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(aLat*rad)*Math.cos(bLat*rad)*Math.sin(dLng/2)*Math.sin(dLng/2);
    return 2*R*Math.asin(Math.sqrt(x));
  }
  function lineLength(cs){ var s=0; for(var i=1;i<cs.length;i++) s+=hav(cs[i-1][0],cs[i-1][1],cs[i][0],cs[i][1]); return s; }
  function lineMidpoint(cs){
    var half=lineLength(cs)/2, acc=0;
    for(var i=1;i<cs.length;i++){
      var seg=hav(cs[i-1][0],cs[i-1][1],cs[i][0],cs[i][1]);
      if(acc+seg>=half && seg>0){ var t=(half-acc)/seg; return [cs[i-1][0]+(cs[i][0]-cs[i-1][0])*t, cs[i-1][1]+(cs[i][1]-cs[i-1][1])*t]; }
      acc+=seg;
    }
    return cs[0];
  }
  function distToSeg(px,py,ax,ay,bx,by){
    var dx=bx-ax, dy=by-ay, l2=dx*dx+dy*dy, t=l2?((px-ax)*dx+(py-ay)*dy)/l2:0;
    t=Math.max(0,Math.min(1,t));
    var cx=ax+t*dx, cy=ay+t*dy; return Math.sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
  }
  function fmtLat(v){ return v.toFixed(6); }                // signed decimal degrees, 6 dp, e.g. -6.820465
  function fmtLen(m){ return Math.round(m)+' m · '+(m/1852).toFixed(2)+' nm · '+(m/1000).toFixed(2)+' km'; }

  /* ---------- MapLibre style fragment ---------- */
  function styleParts(P){
    var d = getData();
    var colorMatch = ['match',['get','cls'],'port',COLORS.port,'starboard',COLORS.starboard,'ferry',COLORS.ferry,'wharf',COLORS.wharf,COLORS.landmark];
    var isSewer = ['==',['get','cls'],'sewer'];
    var none = ['==',['get','id'],''];
    var sources = {}; sources[SRC] = {type:'geojson', data:d.fc};
    var layers = [
      // thin white casing so the black dots stay readable on sea, land and in dark mode (the dotted line itself is #000000 @ 100%)
      {id:'port-sewer-casing', type:'line', source:SRC, filter:isSewer, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':'#FFFFFF','line-opacity':0.75,'line-width':7}},
      {id:'port-sewer-select', type:'line', source:SRC, filter:none, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':'#FFC107','line-opacity':0.9,'line-width':12}},
      // dotted: a (near) zero-length dash with round caps = a round dot; spacing = 2.1 x line width
      {id:'port-sewer', type:'line', source:SRC, filter:isSewer, layout:{'line-cap':'round','line-join':'round'},
        paint:{'line-color':COLORS.sewer,'line-opacity':1,'line-width':3.5,'line-dasharray':[0.1,2]}},
      {id:'port-point-other', type:'circle', source:SRC, minzoom:9,
        filter:['all',['==',['geometry-type'],'Point'],['in',['get','cls'],['literal',OTHER_CLS]]],
        paint:{'circle-radius':['interpolate',['linear'],['zoom'],9,3,14,5,18,8],'circle-color':colorMatch,
               'circle-stroke-color':'#FFFFFF','circle-stroke-width':1.5}},
      {id:'port-buoy', type:'circle', source:SRC,
        filter:['all',['==',['geometry-type'],'Point'],['in',['get','cls'],['literal',BUOY_CLS]]],
        paint:{'circle-radius':['interpolate',['linear'],['zoom'],8,4,12,6,15,8,18,11],'circle-color':colorMatch,
               'circle-opacity':1,'circle-stroke-color':'#FFFFFF','circle-stroke-width':2.2}},
      {id:'port-select-ring', type:'circle', source:SRC, filter:none,
        paint:{'circle-radius':['interpolate',['linear'],['zoom'],8,11,15,16,18,19],'circle-color':'rgba(255,193,7,0.18)',
               'circle-stroke-color':'#FFC107','circle-stroke-width':3}}
    ];
    return {sources:sources, layers:layers};
  }

  /* ---------- UI ---------- */
  function el(tag, css, text){ var e=document.createElement(tag); if(css) e.style.cssText=css; if(text!=null) e.textContent=text; return e; }
  var SURF = 'background:var(--surface,#fff);color:var(--text,#0C1E2E);box-shadow:0 2px 10px rgba(0,0,0,.3);';
  var legendOpen = false;                                  // remembered for the session

  function attach(map, ctx){
    var d = getData();
    if(!d.fc.features.length) return null;
    ctx = ctx || {};
    var tx = ctx.tx || function(k, def){ return def; };
    var P = ctx.P || {label:'#0C1E2E', halo:'#FFFFFF'};
    var overlay = ctx.overlay, markers = ctx.markers || [];
    var typeText = {
      port: tx('tyPort','Port Buoy'), starboard: tx('tyStbd','Starboard Buoy'), sewer: tx('tySewer','Sewer Line'),
      ferry: tx('tyFerry','Ferry'), wharf: tx('tyWharf','Wharf / Pier / Jetty'), landmark: tx('tyLand','Landmark')
    };
    var cleanups = [];

    /* name labels: HTML (no font files -> offline). Created once, only shown/hidden on zoom. */
    var labelEls = [];
    function addLabel(name, lng, lat, minZ, color){
      var e = el('div','pointer-events:none;font:700 11px/1.2 sans-serif;color:'+P.label+';text-shadow:0 0 3px '+P.halo+',0 0 3px '+P.halo+',0 0 3px '+P.halo+';white-space:nowrap;display:none;', name);
      var m = new maplibregl.Marker({element:e, anchor:'top', offset:[0,10]}).setLngLat([lng,lat]).addTo(map);
      markers.push(m); labelEls.push({el:e, z:minZ});
    }
    d.fc.features.forEach(function(f){
      var c = f.properties.cls;
      if(f.geometry.type==='Point') addLabel(f.properties.name, f.geometry.coordinates[0], f.geometry.coordinates[1], BUOY_CLS.indexOf(c)>=0 ? 12.5 : 13);
      else if(c==='sewer'){ var mid = lineMidpoint(f.geometry.coordinates); addLabel(f.properties.name, mid[0], mid[1], 12.5); }
    });
    function updLabels(){ var z = map.getZoom(); labelEls.forEach(function(o){ o.el.style.display = z>=o.z ? 'block':'none'; }); }
    map.on('zoom', updLabels); updLabels();

    /* info panel (top-left, clear of the right-hand controls and the bottom HUD) */
    var panel = el('div','position:absolute;left:10px;right:68px;top:calc(var(--safe-top,0px) + 64px);max-width:340px;padding:10px 12px;border-radius:14px;font:600 13px/1.55 sans-serif;display:none;z-index:2;'+SURF);
    overlay.appendChild(panel);
    var selFilterNone = ['==',['get','id'],''];
    function row(label, val){
      var r = el('div','display:flex;gap:6px;');
      r.appendChild(el('span','opacity:.7;min-width:78px;', label+':'));
      r.appendChild(el('span','font-weight:700;word-break:break-word;', val));
      return r;
    }
    function hidePanel(){
      panel.style.display = 'none';
      map.setFilter('port-select-ring', selFilterNone); map.setFilter('port-sewer-select', selFilterNone);
    }
    function showFeature(f){
      var p = f.properties, g = f.geometry, c = p.cls;
      panel.innerHTML = '';
      var head = el('div','display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:2px;');
      var sw = el('span','flex:none;margin-top:3px;width:12px;height:12px;border-radius:50%;background:'+(COLORS[c]||COLORS.landmark)+';border:2px solid #fff;box-shadow:0 0 0 1px rgba(0,0,0,.35);');
      var title = el('div','flex:1;display:flex;gap:8px;align-items:flex-start;'); title.appendChild(sw);
      title.appendChild(el('div','font-weight:800;font-size:14px;word-break:break-word;', p.name));
      var x = el('button','flex:none;width:44px;height:44px;margin:-10px -12px 0 0;border:0;background:transparent;color:inherit;font-size:18px;', '✕');
      x.setAttribute('aria-label', tx('close','Close')); x.onclick = hidePanel;
      head.appendChild(title); head.appendChild(x); panel.appendChild(head);
      panel.appendChild(row(tx('ptName','Name'), p.name));
      panel.appendChild(row(tx('ptType','Type'), typeText[c] || p.type));
      if(g.type==='Point'){
        panel.appendChild(row(tx('ptLat','Latitude'), fmtLat(g.coordinates[1])));
        panel.appendChild(row(tx('ptLng','Longitude'), fmtLat(g.coordinates[0])));
        map.setFilter('port-select-ring', ['==',['get','id'],p.id]); map.setFilter('port-sewer-select', selFilterNone);
      } else {
        var cs = g.coordinates, a = cs[0], b = cs[cs.length-1];
        panel.appendChild(row(tx('ptStart','Start'), fmtLat(a[1])+', '+fmtLat(a[0])));
        panel.appendChild(row(tx('ptEnd','End'), fmtLat(b[1])+', '+fmtLat(b[0])));
        panel.appendChild(row(tx('ptLength','Length'), fmtLen(lineLength(cs))));
        map.setFilter('port-sewer-select', ['==',['get','id'],p.id]); map.setFilter('port-select-ring', selFilterNone);
      }
      panel.style.display = 'block';
    }

    /* touch picking in SCREEN space (generous 26px / 20px radius, no dependence on layer hit-testing) */
    function onClick(e){
      try{
        var best = null, bestD = 1e9;
        d.points.forEach(function(f){
          var s = map.project(f.geometry.coordinates), dx = s.x-e.point.x, dy = s.y-e.point.y, dd = Math.sqrt(dx*dx+dy*dy);
          if(dd<bestD){ bestD=dd; best=f; }
        });
        if(best && bestD<=26){ showFeature(best); return; }
        var sBest = null, sD = 1e9;
        d.sewers.forEach(function(f){
          var cs = f.geometry.coordinates;
          for(var i=1;i<cs.length;i++){
            var A = map.project(cs[i-1]), B = map.project(cs[i]);
            var dd = distToSeg(e.point.x,e.point.y,A.x,A.y,B.x,B.y);
            if(dd<sD){ sD=dd; sBest=f; }
          }
        });
        if(sBest && sD<=20){ showFeature(sBest); return; }
        hidePanel();
      }catch(err){ if(window.console) console.warn('SeataxiPort click:', err); }
    }
    map.on('click', onClick);

    /* "View Port Features" = fit all imported features. Camera only: never touches the GPS/vessel/navigation data. */
    function fitAll(){
      if(!d.bounds) return;
      if(ctx.setFollow) ctx.setFollow(false);            // stop auto-recentre; user taps ◎ to follow again
      var el0 = map.getContainer(), w = el0.clientWidth, h = el0.clientHeight;
      var hudH = (ctx.hud && ctx.hud.offsetHeight) || 70;
      var pad = {
        top: Math.min(100, h*0.18), bottom: Math.min(hudH+70, h*0.32),
        left: Math.min(36, w*0.1), right: Math.min(84, w*0.2)
      };
      map.fitBounds([[d.bounds[0],d.bounds[1]],[d.bounds[2],d.bounds[3]]], {padding:pad, maxZoom:17, duration:700});
    }
    if(ctx.ctrls){
      var fb = el('button','width:44px;height:44px;border:0;border-radius:12px;font-size:20px;font-weight:700;margin-top:8px;display:block;'+SURF, '⚓');
      var fitLabel = tx('portFit','View Port Features');
      fb.title = fitLabel; fb.setAttribute('aria-label', fitLabel); fb.onclick = fitAll;
      ctx.ctrls.appendChild(fb);
    }

    /* compact, collapsible legend (bottom-left, above the scale bar and the HUD) */
    var legend = el('div','position:absolute;left:10px;bottom:calc(var(--safe-bottom,0px) + var(--hud-h,64px) + 56px);z-index:2;max-width:calc(100% - 80px);');
    var legBtn = el('button','border:0;border-radius:18px;padding:0 14px;height:36px;font:700 12px sans-serif;'+SURF);
    var legBody = el('div','margin-bottom:6px;padding:8px 10px;border-radius:12px;font:600 12px/1.4 sans-serif;'+SURF);
    function legRow(swatch, text){
      var r = el('div','display:flex;align-items:center;gap:8px;padding:3px 0;');
      var box = el('span','flex:none;width:28px;display:flex;justify-content:center;'); box.appendChild(swatch);
      r.appendChild(box); r.appendChild(el('span','', text)); legBody.appendChild(r);
    }
    function dot(color){ return el('span','display:block;width:14px;height:14px;border-radius:50%;background:'+color+';border:2px solid #fff;box-shadow:0 0 0 1px rgba(0,0,0,.35);'); }
    legRow(dot(COLORS.port),      tx('legPort','Red marker — Port Buoy'));
    legRow(dot(COLORS.starboard), tx('legStbd','Green marker — Starboard Buoy'));
    legRow(el('span','display:block;width:28px;height:0;border-top:4px dotted '+COLORS.sewer+';'), tx('legSewer','Black dotted line — Sewer'));
    legRow(dot(COLORS.ferry),     tx('legFerry','Blue marker — Ferry'));
    legRow(dot(COLORS.wharf),     tx('legWharf','Brown marker — Wharf / Pier / Jetty'));
    legRow(dot(COLORS.landmark),  tx('legLand','Violet marker — Landmark'));
    function syncLegend(){
      legBody.style.display = legendOpen ? 'block' : 'none';
      legBtn.textContent = (legendOpen ? '▾ ' : '▸ ') + tx('legTitle','Legend');
      legBtn.setAttribute('aria-expanded', legendOpen ? 'true' : 'false');
    }
    legBtn.onclick = function(){ legendOpen = !legendOpen; syncLegend(); };
    legend.appendChild(legBody); legend.appendChild(legBtn); overlay.appendChild(legend); syncLegend();

    function destroy(){
      try{ map.off('click', onClick); map.off('zoom', updLabels); }catch(e){}
    }
    return {fitAll:fitAll, destroy:destroy, hidePanel:hidePanel};
  }

  window.SeataxiPort = {
    styleParts:styleParts, attach:attach, colors:COLORS,
    _internals:{ getData:getData, lineLength:lineLength, fmtLen:fmtLen }       // used by scripts/test-port-features.mjs
  };
})();
