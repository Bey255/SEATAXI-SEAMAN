// Self-check for the KML port features. Run: node scripts/test-port-features.mjs  (npm run test:port)
// Fails (exit 1) if the generated file is stale/edited, a name/coordinate differs from the KML,
// a buoy has the wrong class/colour, or the sewer style is not black + dotted.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { KML_PATH, OUT_PATH, convert, render } from './kml-to-geojson.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let fails = 0;
const ok = (c, msg) => { console.log((c ? 'PASS  ' : 'FAIL  ') + msg); if (!c) fails++; };

const xml = fs.readFileSync(KML_PATH, 'utf8');
const quiet = { warn() {} };
const { features, skipped } = convert(xml, quiet);
const generated = fs.readFileSync(OUT_PATH, 'utf8');
ok(generated === render({ type: 'FeatureCollection', features }), 'www/map/port-features.js is exactly what the KML converts to (not stale, not hand-edited)');
ok(skipped.length === 0, 'no KML placemark was skipped');

// every KML placemark name + coordinate string appears, unchanged, in the output
const raw = [...xml.matchAll(/<Placemark\b[^>]*>([\s\S]*?)<\/Placemark>/g)].map(m => m[1]);
ok(raw.length === features.length, `placemark count matches (${raw.length} in KML, ${features.length} imported)`);

const sandbox = { window: {} }; vm.createContext(sandbox); vm.runInContext(generated, sandbox);
const fc = sandbox.window.SEATAXI_PORT_FEATURES;
const byName = n => fc.features.find(f => f.properties.name === n);

for (const f of fc.features) {
  const n = f.properties.name, c = f.properties.cls;
  if (/starboard/i.test(n) && /buoy/i.test(n)) ok(c === 'starboard', `"${n}" -> starboard`);
  else if (/port/i.test(n) && /buoy/i.test(n)) ok(c === 'port', `"${n}" -> port`);
}
ok(fc.features.filter(f => f.properties.cls === 'port').length === 14, '14 port buoys');
ok(fc.features.filter(f => f.properties.cls === 'starboard').length === 10, '10 starboard buoys');

const p18 = byName('port buoy 18');
ok(p18 && p18.geometry.coordinates[1].toFixed(6) === '-6.820465' && p18.geometry.coordinates[0].toFixed(6) === '39.302011', 'port buoy 18 = -6.820465, 39.302011 (matches brief example)');
const hc = byName('High Court');
ok(hc && hc.geometry.coordinates[0] === 39.2941888, 'High Court uses the <Point> coordinate, not the LookAt camera');
const sewer = byName('Sewer');
ok(sewer && sewer.geometry.type === 'LineString' && sewer.geometry.coordinates.length === 2, 'Sewer is a 2-vertex LineString');
ok(sewer && sewer.geometry.coordinates[0][0] === 39.29894204194381 && sewer.geometry.coordinates[1][1] === -6.811798428785303, 'Sewer vertices are the KML values, exact');

// style: load seataxi-port.js with a stub window and inspect the layers it emits
const win = { SEATAXI_PORT_FEATURES: fc, console };
const ctx = vm.createContext({ window: win, document: {}, console });
vm.runInContext(fs.readFileSync(path.join(root, 'www/map/seataxi-port.js'), 'utf8'), ctx);
const sp = win.SeataxiPort.styleParts({});
const L = id => sp.layers.find(l => l.id === id);
const matchObj = JSON.stringify(L('port-buoy').paint['circle-color']);
ok(matchObj.includes('"port","#FF0000"') && matchObj.includes('"starboard","#008000"'), 'buoy circle-color: port #FF0000, starboard #008000');
ok(L('port-sewer').paint['line-color'] === '#000000' && L('port-sewer').paint['line-opacity'] === 1, 'sewer line #000000 at opacity 1');
ok(Array.isArray(L('port-sewer').paint['line-dasharray']) && L('port-sewer').layout['line-cap'] === 'round', 'sewer line is dotted (dasharray + round caps), not solid');
ok(L('port-sewer').paint['line-width'] >= 3 && L('port-sewer').paint['line-width'] <= 4, 'sewer line width 3-4 px');
const len = win.SeataxiPort._internals.lineLength(sewer.geometry.coordinates);
ok(len > 900 && len < 1000, `sewer length ~${Math.round(len)} m`);

console.log(fails ? `\n${fails} check(s) FAILED` : '\nAll port-feature checks passed');
process.exit(fails ? 1 : 0);
